---
name: Zenith Architecture
colors:
  surface: '#fbf9f4'
  surface-dim: '#dbdad5'
  surface-bright: '#fbf9f4'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3ee'
  surface-container: '#f0eee9'
  surface-container-high: '#eae8e3'
  surface-container-highest: '#e4e2dd'
  on-surface: '#1b1c19'
  on-surface-variant: '#424843'
  inverse-surface: '#30312e'
  inverse-on-surface: '#f2f1ec'
  outline: '#727972'
  outline-variant: '#c2c8c0'
  surface-tint: '#466550'
  primary: '#163422'
  on-primary: '#ffffff'
  primary-container: '#2d4b37'
  on-primary-container: '#99baa1'
  inverse-primary: '#adcfb4'
  secondary: '#874e52'
  on-secondary: '#ffffff'
  secondary-container: '#fcb4b7'
  on-secondary-container: '#794346'
  tertiary: '#462702'
  on-tertiary: '#ffffff'
  tertiary-container: '#603d16'
  on-tertiary-container: '#daa978'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c8ebd0'
  primary-fixed-dim: '#adcfb4'
  on-primary-fixed: '#022110'
  on-primary-fixed-variant: '#2f4d39'
  secondary-fixed: '#ffdada'
  secondary-fixed-dim: '#fcb4b7'
  on-secondary-fixed: '#360d12'
  on-secondary-fixed-variant: '#6b383b'
  tertiary-fixed: '#ffdcbd'
  tertiary-fixed-dim: '#f0bd8b'
  on-tertiary-fixed: '#2c1600'
  on-tertiary-fixed-variant: '#623f18'
  background: '#fbf9f4'
  on-background: '#1b1c19'
  surface-variant: '#e4e2dd'
typography:
  display-lg:
    fontFamily: Manrope
    fontSize: 48px
    fontWeight: '300'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '400'
    lineHeight: '1.3'
  headline-lg-mobile:
    fontFamily: Manrope
    fontSize: 28px
    fontWeight: '400'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Noto Serif
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Noto Serif
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  gutter: 24px
  margin-mobile: 20px
  margin-desktop: 64px
  container-max: 1280px
---

## Brand & Style

This design system is anchored in the Japanese concept of *Ma* (negative space) and the serene precision of modern architectural visualization. It targets a discerning audience that values tranquility, craftsmanship, and tactile digital experiences.

The visual style is **Tactile Minimalism**. It combines the clean lines of Japanese structuralism with the depth and materiality of a 3D architectural model. Surfaces should feel like physical objects—warm Hinoki wood, textured Washi paper, and smooth stone—interspersed with "light-leak" accents and soft shadows. The emotional response is one of deep focus, calm, and premium quality.

## Colors

The palette is derived from natural Japanese landscapes and materials:
- **Primary (Moss Green):** Used for structural elements, deep-focus backgrounds, and primary actions. It represents stability and nature.
- **Secondary (Sakura Pink):** A soft, desaturated pink used sparingly for highlights, interactive states, and notifications.
- **Tertiary (Hinoki Wood):** A warm, golden oak tone used for tactile borders, sliders, and decorative structural lines.
- **Neutral (Paper White):** The foundation of the UI, utilizing a soft, warm-white hex to mimic handmade Washi paper rather than a sterile digital white.
- **Accent (Sumy Black):** A very dark charcoal (#1A1A1B) used exclusively for high-contrast typography to ensure legibility without breaking the organic feel.

## Typography

The typographic system balances the technical precision of a modern sans-serif with the literary elegance of a classic serif. 

**Manrope** is used for headlines and labels to maintain an architectural, structured feel. High-level displays use light weights and tight tracking for a sophisticated look. **Noto Serif** handles all body content, providing a warm, readable, and human-centric experience that mimics high-end editorial print. Labels and small metadata should always be in uppercase with generous letter spacing to evoke the feeling of blueprints or gallery captions.

## Layout & Spacing

The layout follows a **Fixed Grid** model on desktop to mimic the intentionality of a traditional Japanese floor plan. 

- **Desktop:** A 12-column grid with a 1280px maximum container width. Use wide margins (64px) to create a "gallery" effect.
- **Tablet:** 8-column grid with 32px margins.
- **Mobile:** 4-column grid with 20px margins.

Spacing should be generous and rhythmic, based on an 8px scale. Alignment is strictly forced to the grid to maintain architectural integrity, but individual components may use "asymmetric balance"—where a smaller, heavier element on one side balances a larger, lighter area of white space on the other.

## Elevation & Depth

Hierarchy is established through **Tonal Layers** and **Subtle Materiality** rather than traditional drop shadows.

- **Base Layer:** The "Paper" neutral surface.
- **Raised Surfaces:** Use a subtle 1px border in the Tertiary (Wood) or a slightly darker Neutral to define depth.
- **3D Interaction:** When an element is focused or hovered, apply an "Ambient Lift" using a very soft, multi-layered shadow with a tiny hint of the Moss Green tint. This should feel like the element is physically rising off a table.
- **Translucency:** Use backdrop blurs (20px) on navigation bars to simulate frosted glass or Shoji paper, allowing colors from the background "environment" to bleed through softly.

## Shapes

The shape language is **disciplined and soft**. We avoid sharp 90-degree corners to maintain a natural, handcrafted feel, but we also avoid pill-shapes to stay away from "bubbly" tech aesthetics. 

A consistent **Soft (0.25rem)** radius is applied to most UI containers. Larger cards or sections use **0.5rem (Large)**. This creates a "rounded square" aesthetic common in Japanese product design, signaling both modernism and approachability.

## Components

### Buttons
Primary buttons use the Moss Green background with white Manrope text. Secondary buttons are "Ghost" style with a Hinoki Wood border. All buttons have a 200ms transition that slightly deepens the border color on hover, simulating a physical press.

### Input Fields
Fields are represented as single underlines (Tertiary color) or very subtly tinted blocks. On focus, the underline transforms into a Moss Green line. Labels sit above in uppercase Manrope.

### Cards & Containers
Cards should have no shadow by default, relying on a 1px soft border. If the background is complex, use the Washi Paper color with a 95% opacity and a backdrop blur.

### Chips & Tags
Small, rectangular tags with Soft (1) roundedness. Use secondary Sakura Pink for active tags and light-wood tints for neutral tags.

### Navigation
The primary navigation should feel like a sidebar menu in an architectural app—fixed, minimalist, and utilizing vertical typography for labels where appropriate to mimic Japanese calligraphy layouts.